/************************************************
 * Name: Atlanta Daniel
 * Date: April 24, 2026
 * Assignment: SDC330 Course Project
 * 
 * Main application class.
 */

public class App {
    public static void main(String[] args) throws Exception {
        System.out.println("\nWelcome to the Drive-In Theater Management System!\n");

        //create venues
        Venue venue1 = new Venue(1, "Skyline Drive-In");
        Venue venue2 = new Venue(2, "Bengie's Drive-In");

        //create theaters
        Theater theater1 = new Theater(1, venue2.getVenueID(), venue1.getVenueName(), "3417 Eastern Blvd", "Middle River", "MD", "21220");
        Theater theater2 = new Theater(2, venue1.getVenueID(), venue1.getVenueName(), "31175 Old Hwy 58", "Barstow", "CA", "92311");
        Theater theater3 = new Theater(3, venue1.getVenueID(), venue2.getVenueName(), "5600 Hodgenville Rd", "Greensburg", "KY", "42743");

        //create screens and add to theaters
        Screen screen1 = new Screen(1, 1, 500, theater1.getTheaterID());
        theater1.addScreen(screen1);

        Screen screen2 = new Screen(2, 1, 150, theater2.getTheaterID());
        theater2.addScreen(screen2);

        Screen screen3 = new Screen(3, 2, 300, theater2.getTheaterID());
        theater2.addScreen(screen3);

        Screen screen4 = new Screen(4, 1, 180, theater3.getTheaterID());
        theater3.addScreen(screen4);

        Screen screen5 = new Screen(5, 2, 200, theater3.getTheaterID());
        theater3.addScreen(screen5);

        //create movies
        Movie movie1 = new Movie(1, "Project Hail Mary", "Sci-Fi/Adventure", "PG-13", 157);
        Movie movie2 = new Movie(2, "Michael", "Biography/Drama", "PG-13", 127);
        Movie movie3 = new Movie(3,"Lee Cronin's The Mummy", "Horror", "R", 133);
        Movie movie4 = new Movie(4, "Lorne", "Documentary", "R", 101);

        //create showtimes and assign to screens
        Showtime showTime1 = new Showtime(1, movie1, screen1, "2026-05-01",  "20:00");

        Showtime showTime2 = new Showtime(2, movie3, screen1, "2026-05-01", "23:00");

        Showtime showTime3 = new Showtime(3, movie2, screen4, "2026-05-01", "20:00");

        Showtime showTime4 = new Showtime(4, movie2, screen5, "2026-05-01", "20:30");

        Showtime showTime5 = new Showtime(3, movie4, screen4, "2026-05-01", "22:30");

        Showtime showTime6 = new Showtime(4, movie4, screen5, "2026-05-01", "23:00");



        //display theaters and their showtimes
        System.out.println(theater1.display());
        System.out.println(theater2.display());
        System.out.println(theater3.display());


    }
}
