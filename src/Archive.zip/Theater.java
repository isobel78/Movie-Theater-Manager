/************************************************
 * Name: Atlanta Daniel
 * Date: April 24, 2026
 * Assignment: SDC330 Course Project
 * 
 * This class represents a theater within a venue(chain). It has properties for the specific location and has getters and setters for the properties. It also implements the Displayable interface to provide a string representation of the theater.
 */

import java.util.ArrayList;

public class Theater extends Venue implements Displayable {
    //properties
    private int theaterID;
    private String address;
    private String city;
    private String state;
    private String zip;
    private ArrayList<Screen> screens;

    //constructor
    public Theater(int theaterID, int venueID, String venueName, String address, String city, String state, String zip) {
        super(venueID, venueName);
        this.theaterID = theaterID;
        this.address = address;
        this.city = city;
        this.state = state;
        this.zip = zip;
        this.screens = new ArrayList<>();
    }

    //getters and setters
    //theater ID
    public int getTheaterID() {
        return theaterID;
    }

    //address
    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    //city
    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    //state
    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    //zip
    public String getZip() {
        return zip;
    }

    public void setZip(String zip) {
        this.zip = zip;
    }

    //screens
    public ArrayList<Screen> getScreens() {
        return screens;
    }

    public void addScreen(Screen s) {
        if (s != null) {
            screens.add(s);
        }
    }

    //details method implementation from Venue
    @Override
    public String getDetails() {
        return String.format("Theater ID: %d | Name: %s | Address: %s, %s, %s %s | Screens: %d",
                theaterID, name, address, city, state, zip, screens.size());
    }

    //display method implementation from Displayable
    @Override
    public String display() {
        return getDetails();
    }
}
